package com.varsha.salesorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
