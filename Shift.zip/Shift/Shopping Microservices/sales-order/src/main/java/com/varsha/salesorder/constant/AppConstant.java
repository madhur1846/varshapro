package com.varsha.salesorder.constant;

public class AppConstant {
	
	public static final String CREATED_CUSTOMER = "created-customer";
}
