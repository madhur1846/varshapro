package com.varsha.salesorder.exception;

public class EmptyCartException extends Exception{

	public EmptyCartException(String msg) {
		super(msg);
	}
}
