package com.varsha.salesorder.exception;

import java.util.List;

public class ItemNotFoundException extends Exception{

	public ItemNotFoundException(String msg) {
		super(msg);
	}
}
