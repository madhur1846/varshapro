package com.varsha.salesorder.entity;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderOutput {
	private Long orderId;
	private String orderDescription;
	private Double totalPrice;
	private Set<Item> selectedItems = new HashSet<>();
}
