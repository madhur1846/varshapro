package com.varsha.salesorder.exception;

public class OrderNotFoundException extends Exception{

	public OrderNotFoundException(String msg) {
		super(msg);
	}
}
