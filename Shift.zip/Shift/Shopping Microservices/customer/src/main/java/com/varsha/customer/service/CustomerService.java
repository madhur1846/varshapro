package com.varsha.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.varsha.customer.constant.AppConstant;
import com.varsha.customer.entity.Customer;
import com.varsha.customer.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private KafkaTemplate<String, Customer> kafkaTemplate;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public Customer saveCustomer(Customer customer) {
		Customer savedCustomer = customerRepository.save(customer);
		kafkaTemplate.send(AppConstant.CREATED_CUSTOMER, savedCustomer);
		return savedCustomer;
	}

	public List<Customer> findAllCustomers() {
		return customerRepository.findAll();
	}

	public Customer findCustomerById(Long id) {
		return customerRepository.findCustomerById(id);
	}

}
