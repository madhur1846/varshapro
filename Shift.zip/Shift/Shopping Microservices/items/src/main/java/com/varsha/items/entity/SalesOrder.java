package com.varsha.items.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@Component
public class SalesOrder {
	
	private Long orderId;
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date orderDate;
	
	private String orderDescription;
	
	private int totalPrice;
	
	private Set<Item> selectedItems = new HashSet<>();
}
