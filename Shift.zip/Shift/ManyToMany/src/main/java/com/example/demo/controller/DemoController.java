package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ItemRepo;
import com.example.demo.dto.OrderRepo;
import com.example.demo.entity.Item;
import com.example.demo.entity.Order;
import com.example.demo.feign.ItemsFeign;

@RestController
public class DemoController {
	
	@Autowired
	private ItemsFeign itemsFeign;
	
	@Autowired
	private ItemRepo itemRepo;
	
	@Autowired
	private OrderRepo orderRepo;

	@GetMapping("/welcome")
	public String welcome()
	{
		return "Hello demo project"; 
	}
	
	@GetMapping("/{name}")
	public Item getAll(@PathVariable String name){
		return itemsFeign.findItemByName(name).getBody();
	}
	
	
	@PostMapping("/item/save")
	public Item saveItem(@RequestBody Item item) {
		return itemRepo.save(item);
	}
	@GetMapping("/item")
	public List<Item> findAll(){
		return itemRepo.findAll();
	}
	
	
	@PostMapping("/order/save")
	public Order saveOrder(@RequestBody Order order) {
		Set<Item> selectedItems = new HashSet<>();
		selectedItems.add(itemRepo.findByName("apple"));
		order.setSelectedItems(selectedItems);
		return orderRepo.save(order);
	}
	@GetMapping("/order")
	public List<Order> findAllOrder(){
		return orderRepo.findAll();
	}
	
	
}
